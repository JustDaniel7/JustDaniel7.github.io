import React,{Component} from "react";

class IslandRobots extends Component {
    componentDidMount() {
        window.location.href="http://www.brandx.net/eige/Presentation/webgl_ui/";
    }
    render() {return(<></>)}
}
export default IslandRobots;
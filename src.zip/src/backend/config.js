module.exports = {
    USER: 'daniel.sangermann@hotmail.de',
    PASS: 'Butterflytt1'
}
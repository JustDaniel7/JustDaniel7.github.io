const express = require('express');
const router = express.Router();
const nodemailer = require('nodemailer');
const cors = require('cors');
const creds = require('./config');
const nodeOutlook = require('nodejs-nodemailer-outlook');

const app = express();
app.use(cors());
app.use(express.json())
app.use('/', router)
app.listen(3002)

const transport = {
    host: 'smtp-mail.outlook.com', // Don’t forget to replace with the SMTP host of your provider
    port: 587,
    auth: {
        user: 'daniel.sangermann@hotmail.de',
        pass: 'vqoeyfdegtbleoxe'
    }
};

const transporter = nodemailer.createTransport(transport);

transporter.verify((error) => {
    if (error) {
        console.log(error);
    } else {
        console.log('Server is ready to take messages');
    }
});

router.get('/send',(req,res)=>{
    res.json("/ path found");
})

router.post('/send', (req, res) => {
    let name = req.body.name;
    let email = req.body.email;
    let message = req.body.message;

    const mail = {
        from: 'Someone',
        to: transport.auth.user,  // Change to email address that you want to receive messages on
        subject: 'New Contact Message from ' + name,
        text: `
                From: ${name}, ${email}
                \n
                Message: 
                ${message}`
    }
    transporter.sendMail(mail, (err) => {
        if (!err) {
            res.json({
                status: 'success'
            })
        } else {
            res.json({
                status: 'fail'
            })
        }
    })
})

